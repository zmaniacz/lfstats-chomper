# lfstats-chomper
AWS Lambda function to process SM5 tdf scorecards
